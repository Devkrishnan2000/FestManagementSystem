﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FestManagementApp.Classes
{
    public class Results
    {
        public string Ename;
        public string first;
        public string second;
        public string third;
    }
}
