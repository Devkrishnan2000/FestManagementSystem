﻿using System;
using System.Collections.Generic;
using System.Text;

namespace testapp2
{
   public interface ToastA
    {
        void LongAlert(string message);
        void ShortAlert(string message);
    }
}
