﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace testapp2
{
  public  class Participant
    {
        public string ParticipantName { get; set; }
        public string ParticipantPhone { get; set; }
        public string ParticipantNumber { get; set; }
        public ImageSource imageSource { get; set; }

    }
}
