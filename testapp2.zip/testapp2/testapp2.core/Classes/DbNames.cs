﻿using System;
using System.Collections.Generic;
using System.Text;

namespace testapp2
{
   public  class DbNames
    {
        private string dbnames;


        public string DBName
        {
            get { return dbnames; }
            set { dbnames = value; }
        }
    }
}
