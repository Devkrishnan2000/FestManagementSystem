﻿using System;
using System.Collections.Generic;
using System.Text;

namespace testapp2
{
   public   class EventNames
    {
        private string eventname;

        public string EventName
        {
            get { return eventname; }
            set { eventname = value; }
        }
    }
}
